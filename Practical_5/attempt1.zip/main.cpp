#include "main.h"
#include <iostream>
#include <memory>
using namespace std;

int main()
{
    // Create rooms using smart pointers
    auto livingRoom = make_unique<Room>("Living Room");
    auto kitchen = make_unique<Room>("Kitchen");

    // Create legacy devices using smart pointers
    auto legacyLivingRoomLight = make_unique<LegacyLight>();
    auto legacyFrontDoorLock = make_unique<LegacyDoorLock>();
    auto legacyBackDoorLock = make_unique<LegacyDoorLock>();
    auto legacyThermostat = make_unique<LegacyThermostat>();

    // Create devices that use the legacy devices
    auto livingRoomLight = make_unique<Light>(legacyLivingRoomLight.release());
    auto frontDoorLock = make_unique<DoorLock>(legacyFrontDoorLock.release());
    auto backDoorLock = make_unique<DoorLock>(legacyBackDoorLock.release());
    auto thermo = make_unique<Thermostat>(legacyThermostat.release());

    // Add devices to the living room
    livingRoom->addDevice(move(livingRoomLight));
    livingRoom->addDevice(move(frontDoorLock));
    livingRoom->addDevice(move(backDoorLock));

    // Print the status of the living room
    cout << livingRoom->getStatus() << endl;

    // Create commands using smart pointers
    auto lockAllDoorsCommand = make_unique<LockAllDoors>(livingRoom.get());

    // Create sensors using smart pointers
    auto smokeDetector = make_unique<SmokeDetector>(livingRoom.get(), lockAllDoorsCommand.get());
    auto motionSensor = make_unique<MotionSensor>(livingRoom.get());

    // Add sensors to the room
    livingRoom->addSensor(move(smokeDetector));
    livingRoom->addSensor(move(motionSensor));

    // Create a person using a smart pointer
    auto person = make_unique<Person>("John");
    person->addRoom(livingRoom.get());
    person->addRoom(kitchen.get());

    // Simulate moving to the living room and performing actions
    person->moveToRoom(livingRoom.get());
    cout << "Person is now in the " << livingRoom->getName() << "." << endl;

    // Interact with devices
    // Added a function to turn on devices for clarity
    frontDoorLock->unlock();

    // Trigger motion sensor
    motionSensor->update();

    // Simulate smoke detection
    smokeDetector->update();

    // Print the status of the living room
    cout << livingRoom->getStatus() << endl;

    // Cleanup is automatic due to smart pointers
    return 0;
}
