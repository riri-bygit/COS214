
#include "Sensor.h"

// No implementation needed for the base class; pure virtual functions will be implemented in derived classes.
